// Global variables - only change in 1 place
export const urlPath = "http://localhost:8080/favs/";

export const iTunesUrlPath = `https://itunes.apple.com/search/`;

export const albumUrlPath = `http://localhost:8080/favs/album-info?albumName=`;
